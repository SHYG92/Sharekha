package com.androidbegin.sidemenututorial;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.parse.ParseFile;

public class WorldPopulation {
	private String Event_name; // rank
	private String City_of_event;//Counry
	private String Kind_of_Event;//pop
	private String Organization;
	private String Location;
	private String Target_Group;
	private String Description;
	private String Date;
	private ParseFile  fileObject;
	private byte [] b;
	private String s , Id;
	private String newFormat;
	
	

//----------------------------------
	public String getEvent_name() {
		return Event_name;
	}

	public void setEvent_name(String Event_name) {
		this.Event_name = Event_name;
	}

	public String getCity_of_event() {
		return City_of_event;
	}

	public void setCity_of_event(String City_of_event) {
		this.City_of_event = City_of_event;
	}

	public String getKind_of_Event() {
		return Kind_of_Event;
	}

	public void setKind_of_Event(String Kind_of_Event) {
		this.Kind_of_Event = Kind_of_Event;
	}
	
	public String getOrganization() {
		return Organization;
	}

	public void setOrganization(String Organization) {
		this.Organization = Organization;
	}
	
	public String getLocation() {
		return Location;
	}

	public void setLocation(String Location) {
		this.Location = Location;
	}

	public String getTarget_Group() {
		return Target_Group;
	}

	public void setTarget_Group(String Target_Group) {
		this.Target_Group = Target_Group;
	}
	
	public String getDescription() {
		return Description;
	}

	public void setDescription(String Description) {
		this.Description = Description;
	}
  
	public String getDate() {
		  return newFormat;
		 }

		 public void setDate(Date date) {
		  SimpleDateFormat formatter = new SimpleDateFormat("MMM d, yyyy");
		        String newFormat = formatter.format(date);
		         
		  this.newFormat = newFormat;
		 }
	
	public ParseFile getfileObject() {
		return fileObject;
	}

	public void setfileObject(ParseFile fileObject) {
		this.fileObject = fileObject;
	}

	
	public byte [] getImgByte() {
		return b;
	}

	public void setImgByte(byte [] b) {
		this.b = b;
	}
	
	public String getImgString() {
		return s;
	}

	public void setImgString(String s) {
		this.s = s;
	}
	
	public String getId() {
		return Id;
	}

	public void setId(String Id) {
		this.Id = Id;
	}
	
}