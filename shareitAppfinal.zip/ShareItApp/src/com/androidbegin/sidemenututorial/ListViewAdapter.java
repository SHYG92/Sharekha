package com.androidbegin.sidemenututorial;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.actionbarsherlock.app.SherlockFragment;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ListViewAdapter extends BaseAdapter {

	// Declare Variables
	Context mContext;
	LayoutInflater inflater;
	private List<WorldPopulation> WorldPopulationlist = null;
	private ArrayList<WorldPopulation> arraylist;
//	ImageLoader imageLoader;

	public ListViewAdapter(Context context,
			List<WorldPopulation> WorldPopulationlist) {
		mContext = context;
		this.WorldPopulationlist = WorldPopulationlist;
		inflater = LayoutInflater.from(mContext);
		this.arraylist = new ArrayList<WorldPopulation>();
		this.arraylist.addAll(WorldPopulationlist);
		//imageLoader = new ImageLoader(mContext);
	}

	public class ViewHolder {
		TextView Event_name;
	//	TextView City_of_event;
		//	TextView Kind_of_Event;
		//	TextView Organization;
		//	TextView Location;
		//	TextView Target_Group;
		//	TextView Description;
		TextView Date;
		ImageView flag;;
		 ImageView iv;
		
		
	}

	@Override
	public int getCount() {
		return WorldPopulationlist.size();
	}

	@Override
	public WorldPopulation getItem(int position) {
		return WorldPopulationlist.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	public View getView(final int position, View view, ViewGroup parent) {
		final ViewHolder holder;
		if (view == null) {
			holder = new ViewHolder();
			view = inflater.inflate(R.layout.listview_item, null);
			// Locate the TextViews in listview_item.xml
			holder.Event_name = (TextView) view.findViewById(R.id.Event_name);
	//		holder.City_of_event = (TextView) view.findViewById(R.id.City_of_event);
	//		holder.Kind_of_Event = (TextView) view.findViewById(R.id.Kind_of_Event);
		//	holder.Organization=(TextView)view.findViewById(R.id.Organization);
	//		holder.Location=(TextView)view.findViewById(R.id.Location);
	//		holder.Target_Group=(TextView)view.findViewById(R.id.Target_Group);
	//		holder.Description=(TextView)view.findViewById(R.id.Description);
			  holder.iv=(ImageView) view.findViewById(R.id.s);
			//holder.fileObject=(ImageView)view.findViewById(R.id.fileObject);
			//holder.flag = (ImageView) view.findViewById(R.id.fileObject);
			
			holder.Date=(TextView)view.findViewById(R.id.date);
			view.setTag(holder);
		} else {
			holder = (ViewHolder) view.getTag();
		}
		// Set the results into TextViews
		holder.Event_name.setText(WorldPopulationlist.get(position).getEvent_name());
		holder.Date.setText(WorldPopulationlist.get(position).getDate());
	//	holder.City_of_event.setText(WorldPopulationlist.get(position).getCity_of_event());
	//	holder.Kind_of_Event.setText(WorldPopulationlist.get(position).getKind_of_Event());
	//	holder.Organization.setText(WorldPopulationlist.get(position).getOrganization());
	//	holder.Location.setText(WorldPopulationlist.get(position).getLocation());
	//	holder.Target_Group.setText(WorldPopulationlist.get(position).getTarget_Group());
	//	holder.Description.setText(WorldPopulationlist.get(position).getDescription());
		
		    if( WorldPopulationlist.get(position).getTarget_Group().equals("����"))
	         { //iv.setTag(R.drawable.p);
		    	holder.iv.setImageResource(R.drawable.p);
	 }else if ( WorldPopulationlist.get(position).getTarget_Group().equals("�����")) 
		      {// iv.setTag(R.drawable.o);
		 holder.iv.setImageResource(R.drawable.o);}
	 else if(WorldPopulationlist.get(position).getTarget_Group().equals("����") )
	          {//iv.setTag(R.drawable.b); 
		 holder.iv.setImageResource(R.drawable.b);  }
	 else if(WorldPopulationlist.get(position).getTarget_Group().equals("������"))
	          { holder.iv.setTag(R.drawable.s);
	          holder. iv.setImageResource(R.drawable.s);}       
		 else{//iv.setTag(R.drawable.g);
			 holder.iv.setImageResource(R.drawable.g);}
		//holder.fileObject.setImageResource(WorldPopulationlist.get(position).getfileObject());
		// Bitmap bmp = (Bitmap) (WorldPopulationlist.get(position).getfileObject());
		//holder.flag.setImageResource(worldpopulationlist.get(position).getFlag());
      //  imageLoader.DisplayImage(worldpopulationlist.get(position).getfileObject(), holder.flag); // name Mehod
		//holder.Date.setText(WorldPopulationlist.get(position).getDate());

		// Listen for ListView Item Click
		view.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				
				
				Fragment3 myDetailFragment = new Fragment3();
				    Bundle bundle = new Bundle();
				    bundle.putString("Event_name", WorldPopulationlist.get(position).getEvent_name());
				    bundle.putString("City_of_event",
							(WorldPopulationlist.get(position).getCity_of_event()));
					// Pass all data Kind_of_Event
				    bundle.putString("Kind_of_Event",
							(WorldPopulationlist.get(position).getKind_of_Event()));
				    bundle.putString("Organization",
							(WorldPopulationlist.get(position).getOrganization()));
				    bundle.putString("Location",
							(WorldPopulationlist.get(position).getLocation()));
				    bundle.putString("Target_Group",
							(WorldPopulationlist.get(position).getTarget_Group()));
				    bundle.putString("Description",
							(WorldPopulationlist.get(position).getDescription()));
				    bundle.putString("objectId",
							(WorldPopulationlist.get(position).getId()));
				    bundle.putString("Date",WorldPopulationlist.get(position).getDate());
				//    bundle.putByteArray("Event_image",
				//			(WorldPopulationlist.get(position).getImgByte()));
				    myDetailFragment.setArguments(bundle);
				    if (mContext == null)
			              return;
			         if (mContext instanceof MainActivity) {
			              MainActivity feeds = (MainActivity) mContext;
			              feeds.startFrag(myDetailFragment);  
			         }
				//    ((SherlockFragment) mContext).replace(R.id.content_frame, new AboutAppFragment());
				    
				    
				// Send single item click data to SingleItemView Class
			/*	Intent intent = new Intent(mContext, SingleItemView.class);
				// Pass all data Event_name
				intent.putExtra("Event_name",
						(WorldPopulationlist.get(position).getEvent_name()));
				// Pass all data City_of_event
				intent.putExtra("City_of_event",
						(WorldPopulationlist.get(position).getCity_of_event()));
				// Pass all data Kind_of_Event
				intent.putExtra("Kind_of_Event",
						(WorldPopulationlist.get(position).getKind_of_Event()));
				intent.putExtra("Organization",
						(WorldPopulationlist.get(position).getOrganization()));
				intent.putExtra("Location",
						(WorldPopulationlist.get(position).getLocation()));
				intent.putExtra("Target_Group",
						(WorldPopulationlist.get(position).getTarget_Group()));
				intent.putExtra("Description",
						(WorldPopulationlist.get(position).getDescription()));
				//intent.putExtra("Date",
					//	(WorldPopulationlist.get(position).getDate()));
				
				// Start SingleItemView Class
				mContext.startActivity(intent);*/
			}
		});

		return view;
	}
		
		

	public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        WorldPopulationlist.clear();
        if (charText.length() == 0) {
        	WorldPopulationlist.addAll(arraylist);
        } else {
            for (WorldPopulation wp : arraylist) {
                if (wp.getCity_of_event().toLowerCase(Locale.getDefault())
                        .contains(charText)) {
                	WorldPopulationlist.add(wp);
                }
            }
        }
        notifyDataSetChanged();
    }
 
}
