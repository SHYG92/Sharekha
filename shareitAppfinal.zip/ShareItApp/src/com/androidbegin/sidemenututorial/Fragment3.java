package com.androidbegin.sidemenututorial;

import java.io.ByteArrayOutputStream;
import java.util.List;

import com.actionbarsherlock.app.SherlockFragment;
import com.parse.FindCallback;
import com.parse.GetDataCallback;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseObject;
import com.parse.ParseQuery;



import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class Fragment3 extends SherlockFragment {
	String wid ;
	String detail;
	TextView txtEvent_name;
	TextView txtCity_of_event;
	TextView txtKind_of_Event;
	TextView txtOrganization;
	TextView txtLocation;
	TextView txtDecs;
	TextView txtDate;
	TextView txtTarget;
	String Event_name;
	String City_of_event;
	String Kind_of_Event;
	String Organization;
	String Location , Id , Desc;
	String Date ,Target;
	byte[] b;
	ImageView image;
	ParseQuery<ParseObject> query ;
	 private boolean isCancle = false;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		//Bundle b = getArguments();
     //   wid = b.getString("Event_name");
        Bundle bundle = getArguments();
        if(bundle != null){
       detail = bundle.getString("Event_name");
       Event_name = bundle.getString("Event_name");
   		// Get the results of City_of_event
   		City_of_event = bundle.getString("City_of_event");
   		// Get the results of Kind_of_Event
   		Kind_of_Event = bundle.getString("Kind_of_Event");
   		Organization=bundle.getString("Organization");
   		Location=bundle.getString("Location");
   		b=bundle.getByteArray("Event_image");
   		Id=bundle.getString("objectId");
   		Desc=bundle.getString("Description");
   		Date=bundle.getString("Date");
   		Target=bundle.getString("Target_Group");
       Log.v("DateCon", detail); 
      
        }
		View rootView = inflater.inflate(R.layout.singleitemview, container, false);
		return rootView;
	}
	
    public void onStart() {
        super.onStart();
    
		

		// Locate the TextViews in singleitemview.xml
		txtEvent_name = (TextView) getActivity().findViewById(R.id.Event_name);
		txtCity_of_event = (TextView) getActivity().findViewById(R.id.City_of_event);
		txtKind_of_Event = (TextView) getActivity().findViewById(R.id.Kind_of_Event);
		txtOrganization=(TextView)getActivity().findViewById(R.id.Organization);
		txtLocation=(TextView)getActivity().findViewById(R.id.Location);
		txtDecs=(TextView)getActivity().findViewById(R.id.Description);
		txtDate=(TextView)getActivity().findViewById(R.id.date);
		txtTarget=(TextView)getActivity().findViewById(R.id.Target_Group);

		// Load the results into the TextViews
		txtEvent_name.setText(Event_name);
		txtCity_of_event.setText(City_of_event);
	   txtKind_of_Event.setText(Kind_of_Event);
		txtOrganization.setText(Organization);
		txtLocation.setText(Location);
		txtDecs.setText(Desc);
		txtDate.setText(Date);
		txtTarget.setText(Target);
	       final ProgressBar loadingProgress = (ProgressBar) getActivity().findViewById(R.id.progress);
	    
	       loadingProgress.setVisibility(View.GONE);
	      
	    
	     

//		 Bitmap bmp = BitmapFactory.decodeByteArray(b, 0, b.length);
	        
	       
	        // Get the ImageView from main.xml
	//      image = (ImageView) getActivity().findViewById(R.id.imageView1);

	        // Set the Bitmap into the ImageView
	  //    image.setImageBitmap(bmp);
  
    //    Log.v("DateCon", detail); 
	      
	      query = new ParseQuery<ParseObject>(
					"Events");  
			
		//	ParseFile fileObject = (ParseFile) object.get("Event_image");
			// Locate the column named "Event_namenum" in Parse.com and order list
			// by ascending
			//query.orderByAscending("Event_namenum");
			//edit_text.getText().toString()
		
	      if(image == null){
		   query.whereEqualTo("objectId",Id); 
		
		 query.findInBackground(new FindCallback<ParseObject>() {
			 public void done(List<ParseObject> objects, ParseException e) {
				 if (e == null&& objects != null && objects.size() > 0) {
				    for (final ParseObject parseObject : objects) {
				        ParseFile imageFile = (ParseFile) parseObject.get("Event_image");
				 
				        loadingProgress.setVisibility(View.VISIBLE);
								
							// images
							imageFile.getDataInBackground(new GetDataCallback() {
								@Override

								public void done(byte[] data, ParseException e) {
								 if ( data != null && data.length > 0) {
									Log.d("test", "We've got data in data.");
										// Decode the Byte[] into Bitmap
							Bitmap bmp = BitmapFactory.decodeByteArray(data, 0,data.length);
							 if (!isCancle){
							Bitmap bmp2 = scaleDownBitmap(bmp, 200, getActivity());

						
									ByteArrayOutputStream stream = new ByteArrayOutputStream();
								bmp2.compress(Bitmap.CompressFormat.PNG, 100, stream);
								
							     image = (ImageView) getActivity().findViewById(R.id.imageView1);
							     loadingProgress.setVisibility(View.GONE);
							        // Set the Bitmap into the ImageView
							      image.setImageBitmap(bmp2);
								 }
							
						
							



								} else {
											Log.d("test","There was a problem downloading the data.");
										}
							
				     //end done2
				
				             }

							
								});
								
				        	//end for
								}
									
				         }else { Log.d("test","There was a problem downloading the data.");}
									
						
								}
				        	 });
	      }
	      
		 Button  btntwitter =(Button) getActivity().findViewById(R.id.imageButton1);	
		 btntwitter.setOnClickListener(new OnClickListener() 
		        {
					public void onClick(View v) 
					{ 
						
						//share twitter button 
						
						Intent tweetIntent = new Intent(Intent.ACTION_SEND);
						//���� ��� �������� �� ������� �������� ����
				       // tweetIntent.putExtra(Intent.EXTRA_TEXT,b);
						tweetIntent.putExtra(Intent.EXTRA_TEXT,    "��� ���� �� ������"  + Event_name + "  �� ���� ����� �����ǡ������ ����� ������� �� ��� " );
						tweetIntent.setType("text/plain");

						PackageManager packManager =  getActivity().getPackageManager();
						List<ResolveInfo> resolvedInfoList = packManager.
						        queryIntentActivities(tweetIntent, PackageManager.MATCH_DEFAULT_ONLY);

						boolean resolved = false;
						for(ResolveInfo resolveInfo: resolvedInfoList){
						    if(resolveInfo.activityInfo.packageName.startsWith("com.twitter.android")){
						        tweetIntent.setClassName(resolveInfo.activityInfo.packageName, 
						                resolveInfo.activityInfo.name);
						        resolved = true;
						        break;
						    }
						}
						if(resolved)
						    startActivity(tweetIntent);
						else
						   Toast.makeText( getActivity(),"Twitter isn't found on your system",Toast.LENGTH_LONG).show();
						
					}    });
		 
		 
		 
		 
		 Button  btnflag =(Button) getActivity().findViewById(R.id.imageButton2);	
		 btnflag .setOnClickListener(new OnClickListener() 
		        {
					public void onClick(View v) 
					{ 
				
						   Toast.makeText( getActivity(),"������",Toast.LENGTH_LONG).show();
						
					}    });
		 
		 Button  btnclender =(Button) getActivity().findViewById(R.id.imageButton3);	
		 btnclender.setOnClickListener(new OnClickListener() 
		        {
					public void onClick(View v) 
					{ 
				
						   Toast.makeText( getActivity(),"������",Toast.LENGTH_LONG).show();
						
					}    });
    }
	
	public static Bitmap scaleDownBitmap(Bitmap photo, int newHeight, Context context) {

		final float densityMultiplier = context.getResources().getDisplayMetrics().density;        

		int h= (int) (newHeight*densityMultiplier);
		int w= (int) (h * photo.getWidth()/((double) photo.getHeight()));

		photo=Bitmap.createScaledBitmap(photo, w, h, true);

		return photo;
		}

    
    public void onPause() {
	    super.onPause();
	  
	   
	     isCancle =true;
	}

}
