package com.androidbegin.sidemenututorial;


import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuItem;
import com.androidbegin.sidemenututorial.Fragment1.SelectDateFragment;
import com.androidbegin.sidemenututorial.Fragment2.MyTask;


import com.parse.LogInCallback;
import com.parse.Parse;
import com.parse.ParseAnalytics;
import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.SignUpCallback;

import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.Fragment;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.accounts.AccountManagerCallback;
import android.accounts.AccountManagerFuture;
import android.accounts.AuthenticatorException;
import android.accounts.OperationCanceledException;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v4.view.GravityCompat;

public class MainActivity extends SherlockFragmentActivity implements
AccountManagerCallback<Bundle>  {

	// Declare Variable
	DrawerLayout mDrawerLayout;
	ListView mDrawerList;
	ActionBarDrawerToggle mDrawerToggle;
	static MenuListAdapter mMenuAdapter;
	String[] title;
	String[] title2;
	String[] subtitle;
	int[] icon;
	Fragment fragment1 = new Fragment1();
	Fragment fragment2 = new Fragment2();
	Fragment fragment3 = new Fragment3();
	
	
	//********************************
	
	private static final String TAG = "Fragment2";

	private AccountManager mAccountManager = null;
	private static String sToken = null;
	private Account mAccount = null;
	private String mAuthTokenType = null;
	private static boolean sAuthenticate = false;
	private boolean flag = false;
	private boolean flagnew = false;
	private boolean flag2 = false;
	public static  boolean flagMain = false;
	ArrayList<Account > gUsernameList = new ArrayList<Account>();
	ArrayList<String> UsernameList = new ArrayList<String>();
	static int default_value_tGroup = -1;
	AlertDialog d;
	public String id = null;
	public String name = null;
	Account[] accounts;
	
	 String possibleEmail;
	 String NameEmail;
	 View header ;
	 View header2;
	 
	 MainEventFragment meFragment ;
	
	public static int currnetItem = 1;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.drawer_main);
		

	    if (getIntent().hasExtra("bundle") && savedInstanceState==null){
	        savedInstanceState = getIntent().getExtras().getBundle("bundle");
	    }

	
		      
		   Parse.initialize(this, "9I1Vjexwk5xiELdVT8wPYemAkDPNRg9axGHbuC6m", "0JlABw2JhM0AJJQ9ajiT1A6EI24rrZngQvEi8Bya");
	        ParseAnalytics.trackAppOpened(getIntent());
		// Generate title
		title = new String[] {  "الرئيسية",
				"تسجيل الدخول "  , "إضافة فعالية " , "مساعدة"  , "حول التطبيق " };
		title2 = new String[] { "الرئيسية",
				"تسجيل خروج "  , "إضافة فعالية " , "مساعدة"  , "حول التطبيق " };

		// Generate subtitle
		subtitle = new String[] {  "",
				"" , "" , 	"" , "" };

		// Generate icon
		icon = new int[] {  R.drawable.ic_action_home ,
				R.drawable.ic_action_user , R.drawable.ic_action_add , R.drawable.ic_action_help , R.drawable.ic_action_info};
		ParseUser currentUser = ParseUser.getCurrentUser();
		if (currentUser != null) {
		 	 updateinterface();
        }else {
		// Locate DrawerLayout in drawer_main.xml
		mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

		// Locate ListView in drawer_main.xml
		mDrawerList = (ListView) findViewById(R.id.left_drawer);

		// Set a custom shadow that overlays the main content when the drawer
		// opens
		mDrawerLayout.setDrawerShadow(R.drawable.drawer_shadow,
				GravityCompat.START);

		// Pass results to MenuListAdapter Class
		mMenuAdapter = new MenuListAdapter(this, title , icon);

		
		 header = getLayoutInflater().inflate(R.layout.headlistblank, null);
		mDrawerList.addHeaderView(header);
		// Set the MenuListAdapter to the ListView
		mDrawerList.setAdapter(mMenuAdapter);

		// Capture button clicks on side menu
		mDrawerList.setOnItemClickListener(new DrawerItemClickListener());

		// Enable ActionBar app icon to behave as action to toggle nav drawer
		getSupportActionBar().setHomeButtonEnabled(true);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);

		// ActionBarDrawerToggle ties together the the proper interactions
		// between the sliding drawer and the action bar app icon
		mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
				R.drawable.ic_drawer, R.string.drawer_open,
				R.string.drawer_close) {

			public void onDrawerClosed(View view) {
				// TODO Auto-generated method stub
				super.onDrawerClosed(view);
			}

			public void onDrawerOpened(View drawerView) {
				// TODO Auto-generated method stub
				super.onDrawerOpened(drawerView);
			}
		};
        }

		mDrawerLayout.setDrawerListener(mDrawerToggle);

		if (savedInstanceState == null) {
			selectItem(1);
		}
		
		
		  
	}



	   public void onStart() {
	        super.onStart();
	   }
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		if (item.getItemId() == android.R.id.home) {

			if (mDrawerLayout.isDrawerOpen(mDrawerList)) {
				mDrawerLayout.closeDrawer(mDrawerList);
			} else {
				mDrawerLayout.openDrawer(mDrawerList);
			}
		}

		return super.onOptionsItemSelected(item);
	}

	// The click listener for ListView in the navigation drawer
	private class DrawerItemClickListener implements
			ListView.OnItemClickListener {
		
		
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			selectItem(position);
			
		
		}
	}

	@SuppressLint("NewApi")
	private void selectItem(int position) {

		
		// Locate Position
		switch (position) {
		case 1:{
			  getSupportFragmentManager().beginTransaction().replace(R.id.content_frame,  new MainEventFragment()).commit();
			  currnetItem=1;
			  flagMain = true;
			break;}
		
		case 2:{
		//	new MyDialogFragment().show(ft, "MyDialog");
		  
		        ParseUser currentUser = ParseUser.getCurrentUser();
				if (currentUser != null) {
				  // do stuff with the user
					ParseUser.logOut();
					mMenuAdapter = new MenuListAdapter(this, title, subtitle, icon);
					header = getLayoutInflater().inflate(R.layout.headlistblank, null);
					mDrawerList.removeHeaderView(header2);
					mDrawerList.addHeaderView(header);
					mDrawerList.setAdapter(mMenuAdapter);

						// Capture button clicks on side menu
						mDrawerList.setOnItemClickListener(new DrawerItemClickListener());

						// Enable ActionBar app icon to behave as action to toggle nav drawer
						getSupportActionBar().setHomeButtonEnabled(true);
						getSupportActionBar().setDisplayHomeAsUpEnabled(true);
						mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
								R.drawable.ic_drawer, R.string.drawer_open,
								R.string.drawer_close) {

							public void onDrawerClosed(View view) {
								// TODO Auto-generated method stub
								super.onDrawerClosed(view);
							}

							public void onDrawerOpened(View drawerView) {
								// TODO Auto-generated method stub
								super.onDrawerOpened(drawerView);
							}
						};   
						Log.d(TAG,"log out Done");
						 if (currnetItem==3){
							 getSupportFragmentManager().beginTransaction().replace(R.id.content_frame,  new Fragment1()).commit();
							 currnetItem=3;
							 flagMain=false;
						}
				} else {   DialogFragment newFragment = new MyDialogFragment();
		        newFragment.show(getSupportFragmentManager(), "MyDialog");
		       }
				
		    	mMenuAdapter.notifyDataSetChanged();
		  //  	flagMain=false;
			//ft.replace(R.id.content_frame, fragment3);
			break;
			
		} case 3:{
		
			 getSupportFragmentManager().beginTransaction().replace(R.id.content_frame,  new AddEventFragment()).commit();
				 currnetItem=3;
			//ft.replace(R.id.content_frame,  new Fragment2());
			// getSupportFragmentManager().beginTransaction().replace(R.id.content_frame,  new Fragment2()).commit();
				 flagMain=false;
			break;}
		case 4:{
			
			 getSupportFragmentManager().beginTransaction().replace(R.id.content_frame,  new  HelpFragment()).commit();
			 currnetItem=4;
			 flagMain=false;
		break;}
		case 5:{
			
			 getSupportFragmentManager().beginTransaction().replace(R.id.content_frame,  new AboutAppFragment()).commit();
			 currnetItem=5;
			 flagMain=false;
		break;}
		}
		//ft.commit();
		mDrawerList.setItemChecked(position, true);
		// Close drawer
		mDrawerLayout.closeDrawer(mDrawerList);
	}

	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		// Sync the toggle state after onRestoreInstanceState has occurred.
		mDrawerToggle.syncState();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		// Pass any configuration change to the drawer toggles
		mDrawerToggle.onConfigurationChanged(newConfig);
	}
	
	  @SuppressLint("ValidFragment")
public	class MyDialogFragment extends DialogFragment  {
		

			
	
	    @Override
	    public Dialog onCreateDialog(Bundle savedInstanceState) {
	    	 
	  		
	  		gUsernameList.clear();
	  		 UsernameList.clear();

	  		if (mAccountManager == null) {
	  		    mAccountManager = AccountManager.get(getActivity());
	  		    
	  		}

	  		// 認証するサービスを設定
	  		setAuthTokenType( this.MAIL);
	  		// 起動初回フラグ
	  		flag = true;

	  		 accounts = mAccountManager.getAccountsByType("com.google");
	  		for (Account ac : accounts) {
	  		    // 複数のアカウントがある場合は、複数が取れる
	  		    Log.d(TAG, ac.toString());
	  		    
	  		    gUsernameList.add(ac);
	  		    UsernameList.add(ac.name);
	  		  
	  		    
	  		    
	  		}

	  	

	  		// 1つめのGmailアカウントで認証する
	  		// mAccount = accounts[0];

	  		//AccountManagerFuture<Bundle> accountManagerFuture = mAccountManager.getAuthToken(mAccount,
	  		  //      mAuthTokenType,null, false,  test.this, null);



	  		//-----------------------------------------


	  		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity() );
	  		
	  		builder.setTitle("Choose you gmail-account");


	  		ListView lv = new ListView(getActivity());

	  		ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), R.layout.select_dialog_singlechoice2 ,  UsernameList);
	  		
	  		//----------------------------------------R.style.AlertDialogCustom ------------------------------
	  		AlertDialog.Builder builder2 =
	  		new AlertDialog.Builder( getActivity()  ).setSingleChoiceItems(
	  				adapter, -1,new  DialogInterface.OnClickListener() {

	  		  @Override
	  		  public void onClick(DialogInterface dialog, int position)
	  		  {
	  		  
	  		      default_value_tGroup = position;
	  		      Log.d("You-select-gmail-account", gUsernameList.get(position).name);
	  				 mAccount = gUsernameList.get(position);
  
	  		  }
	  		}).setTitle("آختر الحساب   الخاص بك");
	  		builder2.setPositiveButton("OK", new DialogInterface.OnClickListener() {
	  		    @TargetApi(14)
	  			public void onClick(DialogInterface dialog, int whichButton) {
	  		    	if(default_value_tGroup != -1){
	  		   	 AccountManagerFuture<Bundle> accountManagerFuture = mAccountManager.getAuthToken(mAccount,
	  					        mAuthTokenType ,null, false,  MainActivity.this , null);
	  		        d.dismiss();}
	  		    	else d.dismiss();
	  		    }
	  		});

	  		/* LayoutInflater inflater=LayoutInflater.from(getApplicationContext());
	  		 View customTitle=inflater.inflate(R.layout.title, null);
	  		setCustomTitle(customTitle);*/
	  		LayoutInflater inflater = (LayoutInflater)getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	  		View view = inflater.inflate(R.layout.title, null);
	  	//	builder2.setView(view);
	  	//	builder2.setView(view);
	  		TextView title = new TextView(getActivity());
	  		// You Can Customise your Title here 
	  		/*title.setText("Custom Centered Title");
	  		title.setBackgroundColor(Color.DKGRAY);
	  		title.setPadding(10, 10, 10, 10);
	  		title.setGravity(Gravity.CENTER);
	  		title.setTextColor(Color.WHITE);
	  		title.setTextSize(20);*/
	  	//	builder2.setCustomTitle(view);
	 
	  		d = builder2.create();
	  		d.show();

	  		
	  		 return d;
	  		}



		public void setAuthTokenType(String type) {
		mAuthTokenType = type;
		}

		/**
		* 認証結果のコールバック
		*/
		
		public void run(AccountManagerFuture<Bundle> data) {
		Bundle bundle;
		try {
		    bundle = data.getResult();
		    Intent intent = (Intent) bundle.get(AccountManager.KEY_INTENT);
		    if (intent != null) {
		        if (flag) {
		            // ユーザ認証画面起動
		            flag = false;
		            startActivity(intent);
		        } else {
		            // 2度目の起動はせずに終了する
		        	getActivity().finish();
		        }
		    } else {
		        // トークン取得
		        sToken = bundle.getString(AccountManager.KEY_AUTHTOKEN);
		        // サービス認証
		       // loginGoogle();
		         new  MyTask(). execute();
				 
		    }
		} catch (OperationCanceledException e) {
		    e.printStackTrace();
		} catch (AuthenticatorException e) {
		    e.printStackTrace();
		} catch (IOException e) {
		    e.printStackTrace();
		}
		}

		/**
		* Googleのサービスの認証
		*/
		private void loginGoogle() {
		DefaultHttpClient http_client = new DefaultHttpClient();
		HttpGet http_get = new HttpGet("https://www.google.com/accounts/TokenAuth?auth=" + sToken
		        + "&service=" + mAuthTokenType + "&source=Android"
		        + "&continue=http://www.google.com/");
		HttpResponse response = null;
		try {
		    response = http_client.execute(http_get);
		} catch (ClientProtocolException e) {
		    e.printStackTrace();
		} catch (IOException e) {
		    e.printStackTrace();
		}
		if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
		    try {
		        String entity = EntityUtils.toString(response.getEntity());
		        Log.d(TAG, entity);
		        if (entity.contains("The page you requested is invalid")) {
		            Log.d(TAG, "The page you requested is invalid");
		            mAccountManager.invalidateAuthToken("com.google", sToken);
		        } else {
		            // 認証に成功した
		            sAuthenticate = true;
		            Log.d(TAG, "Authentication Success");
		          //  Toast.makeText(this, "Authentication Success", Toast.LENGTH_LONG).show();
		        }
		    } catch (IllegalStateException e) {
		        e.printStackTrace();
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		} else {
		    Log.d(TAG, "Login failure");
		}
		}


		
		
		public class MyTask extends AsyncTask<Void, Void, Void> {
			 ProgressDialog progressDialog ;
			
		    protected void onPreExecute() {
		    	 progressDialog = ProgressDialog.show( getActivity(),
		                 "", "يتم الان التحميل نرجو الإنتظار ...", true);
		    
		         
		    }
		  
		    @SuppressLint("NewApi")
			protected Void doInBackground(Void... arg0) {
		    	DefaultHttpClient http_client = new DefaultHttpClient();
		    	HttpGet http_get = new HttpGet("https://www.google.com/accounts/TokenAuth?auth=" + sToken
		    	        + "&service=" + mAuthTokenType + "&source=Android"
		    	        + "&continue=http://www.google.com/");
		    	
		    	HttpResponse response = null;

		    	try {
		    		
		    
		    		
		    	    response = http_client.execute(http_get);
		    	     possibleEmail = mAccount.name;
		    	     NameEmail = mAccount.name;
		    
		    	
		    	    Log.d(TAG, possibleEmail);
		    	    
		    	    if(!possibleEmail.isEmpty()){
		    	        
		    	        String[] parts = possibleEmail.split("@");
		    	        if(parts.length > 0 && parts[0] != null)
		    	        	NameEmail = parts[0];
		    	        else
		    	            return null;
		    	    }else
		    	        return null;
		    	   
		    	} catch (ClientProtocolException e) {
		    	    e.printStackTrace();
		    	} catch (IOException e) {
		    	    e.printStackTrace();
		    	}
		    	if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
		    	    try {
		    	        String entity = EntityUtils.toString(response.getEntity());
		    	   
						 
		    	        Log.d(TAG, entity);
		    	        if (entity.contains("The page you requested is invalid")) {
		    	            Log.d(TAG, "The page you requested is invalid");
		    	            mAccountManager.invalidateAuthToken("com.google", sToken);
		    	        } else {
		    	            // 認証に成功した
		    	            sAuthenticate = true;
		    	            ParseUser user = new ParseUser();
		    				user.setUsername(NameEmail);
		    				user.setPassword("123456");
		    				user.setEmail(possibleEmail);
		    				 
		    				// other fields can be set just like with ParseObject
		    	
		    				 
		    				user.signUpInBackground(new SignUpCallback() {
		    				  public void done(ParseException e) {
		    				    if (e == null) {
		    				      // Hooray! Let them use the app now.
		    				    	 Log.d(TAG, "sign up  Done");
		    				    	
		    				    } else if (e.getMessage().equals("username " +NameEmail+ " already taken" ) || e.getMessage().equals("the email address " +possibleEmail+ "has already been taken")) {
		    				      // Sign up didn't succeed. Look at the ParseException
		    				      // to figure out what went wrong
		    				    		
		    				  	  ParseUser.logInInBackground(NameEmail, "123456", new LogInCallback() {
		    			        	  public void done(ParseUser user, ParseException e) {
		    			        	    if (user != null) {
		    			        	      // Hooray! The user is logged in.
		    			        	    	Log.d(TAG," log in Done");
		    			        	    	
		    			        	    	
		    			        	    	
		    			        	    	 if (currnetItem==3){
		    			    					 getSupportFragmentManager().beginTransaction().replace(R.id.content_frame,  new AddEventFragment()).commit();
		    			    				}
		    			        	    	 
		    			        	    	 updateinterface();
		    			        	    	 
		    			        	    	 
		    			        	   	
		    			        	    } else {
		    			        	    	Log.d(TAG,"log in not Done");
		    			        	      // Signup failed. Look at the ParseException to see what happened.
		    			        	    }
		    			        	  }
		    			        	});
		    				    	Log.d(TAG,"please log in");
		    				    	Log.d(TAG, "sign up not Done");
		    				    	Log.d(TAG, e.getMessage());
		    				    }
		    				  }
		    				});
		    	            Log.d(TAG, "Authentication Success");
		    	         //   Toast.makeText(test.this, "Authentication Success", Toast.LENGTH_LONG).show();
		    	        }
		    	    } catch (IllegalStateException e) {
		    	        e.printStackTrace();
		    	    } catch (IOException e) {
		    	        e.printStackTrace();
		    	    }
		    	} else {
		    	    Log.d(TAG, "Login failure");
		    	}
		       
		        return null;
		}
		protected void onPostExecute(Void Result){
			
			progressDialog .dismiss();
			/* progressDialog = ProgressDialog.show(test.this,
		             "", "Done...", true);*/
		}
		}

		/**
		* 認証できているかどうか
		* 
		* @return
		*/
		public boolean getAutheticateState() {
		return sAuthenticate;
		}

		/**
		* 取得したトークンを返す
		* 
		* @return
		*/
		public String getToken() {
		return sToken;
		}

		public static final String ANDROID = "android";
		public static final String APP_ENGINE = "ah";
		public static final String CALENDAR = "cl";
		public static final String MAIL = "mail";
		public static final String TALK = "talk";
		public static final String YOUTUBE = "youtube";
		public static final String FUSION_TABLES = "fusiontables";
	       
	
		
	    }
	  
	  
	    public void updateinterface() {
	    	
	    	mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

			// Locate ListView in drawer_main.xml
			mDrawerList = (ListView) findViewById(R.id.left_drawer);

			// Set a custom shadow that overlays the main content when the drawer
			// opens
			mDrawerLayout.setDrawerShadow(R.drawable.drawer_shadow,
					GravityCompat.START);

			// Pass results to MenuListAdapter Class
			mMenuAdapter = new MenuListAdapter(this, title2 , icon);
			header2 = getLayoutInflater().inflate(R.layout.headlist, null);
			Button p1_button = (Button)header2.findViewById(R.id.buttonEmail);
			   ParseUser currentUser = ParseUser.getCurrentUser();
			p1_button.setText(currentUser.getEmail()+" : الحساب   ");
			mDrawerList.removeHeaderView(header);
			mDrawerList.addHeaderView(header2);

			// Set the MenuListAdapter to the ListView
			mDrawerList.setAdapter(mMenuAdapter);

			// Capture button clicks on side menu
			mDrawerList.setOnItemClickListener(new DrawerItemClickListener());

			// Enable ActionBar app icon to behave as action to toggle nav drawer
			getSupportActionBar().setHomeButtonEnabled(true);
			getSupportActionBar().setDisplayHomeAsUpEnabled(true);

			// ActionBarDrawerToggle ties together the the proper interactions
			// between the sliding drawer and the action bar app icon
			mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
					R.drawable.ic_drawer, R.string.drawer_open,
					R.string.drawer_close) {

				public void onDrawerClosed(View view) {
					// TODO Auto-generated method stub
					super.onDrawerClosed(view);
				}

				public void onDrawerOpened(View drawerView) {
					// TODO Auto-generated method stub
					super.onDrawerOpened(drawerView);
				}
			};
	    }
	   
	
	  
		 @Override
			public void onResume() {
					super.onResume();
					 
					//getFragmentManager().popBackStack();
				}
	  
		 
		 public void startFrag(Fragment fragment){
				///  getFragmentManager().beginTransaction().show(  new AboutAppFragment());
				  
				  FragmentTransaction transaction =  getSupportFragmentManager().beginTransaction();

				// Replace whatever is in the fragment_container view with this fragment,
				// and add the transaction to the back stack
				transaction.replace(R.id.content_frame, fragment);
			
				transaction.addToBackStack(null);
				// Commit the transaction
				transaction.commit();
			}
		 
		 
		 public void startFrag(){
				///  getFragmentManager().beginTransaction().show(  new AboutAppFragment());
				  
			  getSupportFragmentManager().beginTransaction().replace(R.id.content_frame,  new MainEventFragment()).commit();
			  currnetItem=1;
			  flagMain = true;
			}
		 
		 
	
		 
		 public  void onBackPressed() {
			 if (getSupportFragmentManager().getBackStackEntryCount() != 0){ 
				 getSupportFragmentManager().popBackStack();
		             if(!flagMain){this.finish();}
		             if(!flagnew){startFrag();}
		            }else { this.finish();}
	}



			public void run(AccountManagerFuture<Bundle> data) {
				Bundle bundle;
				try {
				    bundle = data.getResult();
				    Intent intent = (Intent) bundle.get(AccountManager.KEY_INTENT);
				    if (intent != null) {
				        if (flag) {
				            // ユーザ認証画面起動
				            flag = false;
				            startActivity(intent);
				        } else {
				            // 2度目の起動はせずに終了する
				        	this.finish();
				        }
				    } else {
				        // トークン取得
				        sToken = bundle.getString(AccountManager.KEY_AUTHTOKEN);
				        // サービス認証
				       // loginGoogle();
				         new  MyTask(). execute();
						 
				    }
				} catch (OperationCanceledException e) {
				    e.printStackTrace();
				} catch (AuthenticatorException e) {
				    e.printStackTrace();
				} catch (IOException e) {
				    e.printStackTrace();
				}
				}

				/**
				* Googleのサービスの認証
				*/
				private void loginGoogle() {
				DefaultHttpClient http_client = new DefaultHttpClient();
				HttpGet http_get = new HttpGet("https://www.google.com/accounts/TokenAuth?auth=" + sToken
				        + "&service=" + mAuthTokenType + "&source=Android"
				        + "&continue=http://www.google.com/");
				HttpResponse response = null;
				try {
				    response = http_client.execute(http_get);
				} catch (ClientProtocolException e) {
				    e.printStackTrace();
				} catch (IOException e) {
				    e.printStackTrace();
				}
				if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
				    try {
				        String entity = EntityUtils.toString(response.getEntity());
				        Log.d(TAG, entity);
				        if (entity.contains("The page you requested is invalid")) {
				            Log.d(TAG, "The page you requested is invalid");
				            mAccountManager.invalidateAuthToken("com.google", sToken);
				        } else {
				            // 認証に成功した
				            sAuthenticate = true;
				            Log.d(TAG, "Authentication Success");
				          //  Toast.makeText(this, "Authentication Success", Toast.LENGTH_LONG).show();
				        }
				    } catch (IllegalStateException e) {
				        e.printStackTrace();
				    } catch (IOException e) {
				        e.printStackTrace();
				    }
				} else {
				    Log.d(TAG, "Login failure");
				}
				}


				
				
				public class MyTask extends AsyncTask<Void, Void, Void> {
					 ProgressDialog progressDialog ;
					
				    protected void onPreExecute() {
				    	 progressDialog = ProgressDialog.show( MainActivity.this,
				                 "", "يتم الان التحميل نرجو الإنتظار ...", true);
				    
				         
				    }
				  
				    @SuppressLint("NewApi")
					protected Void doInBackground(Void... arg0) {
				    	DefaultHttpClient http_client = new DefaultHttpClient();
				    	HttpGet http_get = new HttpGet("https://www.google.com/accounts/TokenAuth?auth=" + sToken
				    	        + "&service=" + mAuthTokenType + "&source=Android"
				    	        + "&continue=http://www.google.com/");
				    	
				    	HttpResponse response = null;

				    	try {
				    		
				    
				    		
				    	    response = http_client.execute(http_get);
				    	     possibleEmail = mAccount.name;
				    	     NameEmail = mAccount.name;
				    
				    	
				    	    Log.d(TAG, possibleEmail);
				    	    
				    	    if(!possibleEmail.isEmpty()){
				    	        
				    	        String[] parts = possibleEmail.split("@");
				    	        if(parts.length > 0 && parts[0] != null)
				    	        	NameEmail = parts[0];
				    	        else
				    	            return null;
				    	    }else
				    	        return null;
				    	   
				    	} catch (ClientProtocolException e) {
				    	    e.printStackTrace();
				    	} catch (IOException e) {
				    	    e.printStackTrace();
				    	}
				    	if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
				    	    try {
				    	        String entity = EntityUtils.toString(response.getEntity());
				    	   
								 
				    	        Log.d(TAG, entity);
				    	        if (entity.contains("The page you requested is invalid")) {
				    	            Log.d(TAG, "The page you requested is invalid");
				    	            mAccountManager.invalidateAuthToken("com.google", sToken);
				    	        } else {
				    	            // 認証に成功した
				    	            sAuthenticate = true;
				    	            ParseUser user = new ParseUser();
				    				user.setUsername(NameEmail);
				    				user.setPassword("123456");
				    				user.setEmail(possibleEmail);
				    				 
				    				// other fields can be set just like with ParseObject
				    	
				    				 
				    				user.signUpInBackground(new SignUpCallback() {
				    				  public void done(ParseException e) {
				    				    if (e == null) {
				    				      // Hooray! Let them use the app now.
				    				    	 Log.d(TAG, "sign up  Done");
				    				    	
				    				    } else if (e.getMessage().equals("username " +NameEmail+ " already taken" ) || e.getMessage().equals("the email address " +possibleEmail+ "has already been taken")) {
				    				      // Sign up didn't succeed. Look at the ParseException
				    				      // to figure out what went wrong
				    				    		
				    				  	  ParseUser.logInInBackground(NameEmail, "123456", new LogInCallback() {
				    			        	  public void done(ParseUser user, ParseException e) {
				    			        	    if (user != null) {
				    			        	      // Hooray! The user is logged in.
				    			        	    	Log.d(TAG," log in Done");
				    			        	    	
				    			        	    	
				    			        	    	
				    			        	    	 if (currnetItem==3){
				    			    					 getSupportFragmentManager().beginTransaction().replace(R.id.content_frame,  new AddEventFragment()).commit();
				    			    				}
				    			        	    	 
				    			        	    	 updateinterface();
				    			        	    	 
				    			        	    	 
				    			        	   	
				    			        	    } else {
				    			        	    	Log.d(TAG,"log in not Done");
				    			        	      // Signup failed. Look at the ParseException to see what happened.
				    			        	    }
				    			        	  }
				    			        	});
				    				    	Log.d(TAG,"please log in");
				    				    	Log.d(TAG, "sign up not Done");
				    				    	Log.d(TAG, e.getMessage());
				    				    }
				    				  }
				    				});
				    	            Log.d(TAG, "Authentication Success");
				    	         //   Toast.makeText(test.this, "Authentication Success", Toast.LENGTH_LONG).show();
				    	        }
				    	    } catch (IllegalStateException e) {
				    	        e.printStackTrace();
				    	    } catch (IOException e) {
				    	        e.printStackTrace();
				    	    }
				    	} else {
				    	    Log.d(TAG, "Login failure");
				    	}
				       
				        return null;
				}
				protected void onPostExecute(Void Result){
					
					progressDialog .dismiss();
					/* progressDialog = ProgressDialog.show(test.this,
				             "", "Done...", true);*/
				}
				}



	

	

	  

}
