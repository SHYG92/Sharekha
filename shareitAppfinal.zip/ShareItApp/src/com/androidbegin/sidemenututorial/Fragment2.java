package com.androidbegin.sidemenututorial;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;


import com.actionbarsherlock.app.SherlockFragment;
import com.parse.LogInCallback;
import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.SignUpCallback;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.accounts.AccountManagerCallback;
import android.accounts.AccountManagerFuture;
import android.accounts.AuthenticatorException;
import android.accounts.OperationCanceledException;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class Fragment2 extends SherlockFragment implements
AccountManagerCallback<Bundle> {
	private static final String TAG = "Fragment2";

	private AccountManager mAccountManager = null;
	private static String sToken = null;
	private Account mAccount = null;
	private String mAuthTokenType = null;
	private static boolean sAuthenticate = false;
	private boolean flag = false;
	ArrayList<Account > gUsernameList = new ArrayList<Account>();
	ArrayList<String> UsernameList = new ArrayList<String>();
	static int default_value_tGroup = -1;
	AlertDialog d;
	public String id = null;
	public String name = null;
	Account[] accounts;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.x, container, false);
		return rootView;
	}
	

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	   @Override
	    public void onStart() {
	        super.onStart();
		
		gUsernameList.clear();

		if (mAccountManager == null) {
		    mAccountManager = AccountManager.get(getActivity());
		    
		}

		// 認証するサービスを設定
		setAuthTokenType(this.MAIL);
		// 起動初回フラグ
		flag = true;

		 accounts = mAccountManager.getAccountsByType("com.google");
		for (Account ac : accounts) {
		    // 複数のアカウントがある場合は、複数が取れる
		    Log.d(TAG, ac.toString());
		    
		    gUsernameList.add(ac);
		    UsernameList.add(ac.name);
		  
		    
		    
		}

		Button button = (Button) getActivity().findViewById(R.id.button1);
		button.setOnClickListener(new OnClickListener() {
			 

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				ParseUser currentUser = ParseUser.getCurrentUser();
				if (currentUser != null) {
				  // do stuff with the user
					ParseUser.logOut();
					 Intent myIntent = new Intent(
							 getActivity(), MainActivity.class);
					 startActivity(myIntent);
						Log.d(TAG,"log out Done");
				} else {
				  // show the signup or login screen
				
				}
			


			}

		});


		// 1つめのGmailアカウントで認証する
		// mAccount = accounts[0];

		//AccountManagerFuture<Bundle> accountManagerFuture = mAccountManager.getAuthToken(mAccount,
		  //      mAuthTokenType,null, false,  test.this, null);



		//-----------------------------------------


		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		builder.setTitle("Choose you gmail-account");


		ListView lv = new ListView(getActivity());

		ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), R.layout.select_dialog_singlechoice2 ,  UsernameList);
		//builder.setGravity(Gravity.RIGHT);


		/*lv.setAdapter(adapter);

		lv.setOnItemClickListener(new OnItemClickListener() {    
		  

			@Override
			public void onItemClick(AdapterView<?> parent,View view,int position,long id) {
				// TODO Auto-generated method stub
				 Log.d("You-select-gmail-account", gUsernameList.get(position).name);
				 mAccount = gUsernameList.get(position);
				
				
			}
		});
		builder.setView(lv);
		builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
		    public void onClick(DialogInterface dialog, int whichButton) {
		    	 AccountManagerFuture<Bundle> accountManagerFuture = mAccountManager.getAuthToken(mAccount,
					        mAuthTokenType,null, false,  test.this, null);
		        dialog.dismiss();
		    }
		});
		final Dialog dialog = builder.create();
		dialog.show();
		*/
		//----------------------------------------------------------------------
		AlertDialog.Builder builder2 =
		new AlertDialog.Builder( getActivity()).setSingleChoiceItems(
				adapter, -1,new  DialogInterface.OnClickListener() {

		  @Override
		  public void onClick(DialogInterface dialog, int position)
		  {
		  
		      default_value_tGroup = position;
		      Log.d("You-select-gmail-account", gUsernameList.get(position).name);
				 mAccount = gUsernameList.get(position);
				 
				 
				 
				 
				 ///---------------------------------------
			


		      
		  
		  }
		}).setTitle("آختر الحساب   الخاص بك");
		builder2.setPositiveButton("OK", new DialogInterface.OnClickListener() {
		    @TargetApi(14)
			public void onClick(DialogInterface dialog, int whichButton) {
		    	if(default_value_tGroup != -1){
		   	 AccountManagerFuture<Bundle> accountManagerFuture = mAccountManager.getAuthToken(mAccount,
					        mAuthTokenType,null, false, Fragment2.this , null);
		        d.dismiss();}
		    	else d.dismiss();
		    }
		});
		d = builder2.create();
		d.show();

		}

		/*
		@Override
		protected void onResume() {
		super.onResume();

		Account[] accounts = mAccountManager.getAccountsByType("com.google");
		for (Account ac : accounts) {
		    // 複数のアカウントがある場合は、複数が取れる
		    Log.d(TAG, ac.toString());
		}
		// 1つめのGmailアカウントで認証する
		mAccount = accounts[0];
		AccountManagerFuture<Bundle> accountManagerFuture = mAccountManager.getAuthToken(mAccount,
		        mAuthTokenType,null, false,  test.this, null);
		}*/

		/**
		* 認証するサービスの設定
		* 
		* @param type
		*/
		public void setAuthTokenType(String type) {
		mAuthTokenType = type;
		}

		/**
		* 認証結果のコールバック
		*/
		@Override
		public void run(AccountManagerFuture<Bundle> data) {
		Bundle bundle;
		try {
		    bundle = data.getResult();
		    Intent intent = (Intent) bundle.get(AccountManager.KEY_INTENT);
		    if (intent != null) {
		        if (flag) {
		            // ユーザ認証画面起動
		            flag = false;
		            startActivity(intent);
		        } else {
		            // 2度目の起動はせずに終了する
		        	getActivity().finish();
		        }
		    } else {
		        // トークン取得
		        sToken = bundle.getString(AccountManager.KEY_AUTHTOKEN);
		        // サービス認証
		       // loginGoogle();
		         new  MyTask(). execute();
				 
		    }
		} catch (OperationCanceledException e) {
		    e.printStackTrace();
		} catch (AuthenticatorException e) {
		    e.printStackTrace();
		} catch (IOException e) {
		    e.printStackTrace();
		}
		}

		/**
		* Googleのサービスの認証
		*/
		private void loginGoogle() {
		DefaultHttpClient http_client = new DefaultHttpClient();
		HttpGet http_get = new HttpGet("https://www.google.com/accounts/TokenAuth?auth=" + sToken
		        + "&service=" + mAuthTokenType + "&source=Android"
		        + "&continue=http://www.google.com/");
		HttpResponse response = null;
		try {
		    response = http_client.execute(http_get);
		} catch (ClientProtocolException e) {
		    e.printStackTrace();
		} catch (IOException e) {
		    e.printStackTrace();
		}
		if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
		    try {
		        String entity = EntityUtils.toString(response.getEntity());
		        Log.d(TAG, entity);
		        if (entity.contains("The page you requested is invalid")) {
		            Log.d(TAG, "The page you requested is invalid");
		            mAccountManager.invalidateAuthToken("com.google", sToken);
		        } else {
		            // 認証に成功した
		            sAuthenticate = true;
		            Log.d(TAG, "Authentication Success");
		          //  Toast.makeText(this, "Authentication Success", Toast.LENGTH_LONG).show();
		        }
		    } catch (IllegalStateException e) {
		        e.printStackTrace();
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		} else {
		    Log.d(TAG, "Login failure");
		}
		}


		public class MyTask extends AsyncTask<Void, Void, Void> {
			 ProgressDialog progressDialog ;
			 String possibleEmail;
			 String NameEmail;
		    protected void onPreExecute() {
		    	 progressDialog = ProgressDialog.show( getActivity(),
		                 "", "Loading. Please wait...", true);
		         
		    }
		  
		    @SuppressLint("NewApi")
			protected Void doInBackground(Void... arg0) {
		    	DefaultHttpClient http_client = new DefaultHttpClient();
		    	HttpGet http_get = new HttpGet("https://www.google.com/accounts/TokenAuth?auth=" + sToken
		    	        + "&service=" + mAuthTokenType + "&source=Android"
		    	        + "&continue=http://www.google.com/");
		    	
		    	HttpResponse response = null;

		    	try {
		    		
		    
		    		
		    	    response = http_client.execute(http_get);
		    	     possibleEmail = mAccount.name;
		    	     NameEmail = mAccount.name;
		    
		    	
		    	    Log.d(TAG, possibleEmail);
		    	    
		    	    if(!possibleEmail.isEmpty()){
		    	        
		    	        String[] parts = possibleEmail.split("@");
		    	        if(parts.length > 0 && parts[0] != null)
		    	        	NameEmail = parts[0];
		    	        else
		    	            return null;
		    	    }else
		    	        return null;
		    	   
		    	} catch (ClientProtocolException e) {
		    	    e.printStackTrace();
		    	} catch (IOException e) {
		    	    e.printStackTrace();
		    	}
		    	if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
		    	    try {
		    	        String entity = EntityUtils.toString(response.getEntity());
		    	   
						 
		    	        Log.d(TAG, entity);
		    	        if (entity.contains("The page you requested is invalid")) {
		    	            Log.d(TAG, "The page you requested is invalid");
		    	            mAccountManager.invalidateAuthToken("com.google", sToken);
		    	        } else {
		    	            // 認証に成功した
		    	            sAuthenticate = true;
		    	            ParseUser user = new ParseUser();
		    				user.setUsername(NameEmail);
		    				user.setPassword("123456");
		    				user.setEmail(possibleEmail);
		    				 
		    				// other fields can be set just like with ParseObject
		    	
		    				 
		    				user.signUpInBackground(new SignUpCallback() {
		    				  public void done(ParseException e) {
		    				    if (e == null) {
		    				      // Hooray! Let them use the app now.
		    				    	 Log.d(TAG, "sign up  Done");
		    				    	
		    				    } else if (e.getMessage().equals("username " +NameEmail+ " already taken" ) || e.getMessage().equals("the email address " +possibleEmail+ "has already been taken")) {
		    				      // Sign up didn't succeed. Look at the ParseException
		    				      // to figure out what went wrong
		    				    		
		    				  	  ParseUser.logInInBackground(NameEmail, "123456", new LogInCallback() {
		    			        	  public void done(ParseUser user, ParseException e) {
		    			        	    if (user != null) {
		    			        	      // Hooray! The user is logged in.
		    			        	    	Log.d(TAG," log in Done");
		    			        	   	
		    			        	    } else {
		    			        	    	Log.d(TAG,"log in not Done");
		    			        	      // Signup failed. Look at the ParseException to see what happened.
		    			        	    }
		    			        	  }
		    			        	});
		    				    	Log.d(TAG,"please log in");
		    				    	Log.d(TAG, "sign up not Done");
		    				    	Log.d(TAG, e.getMessage());
		    				    }
		    				  }
		    				});
		    	            Log.d(TAG, "Authentication Success");
		    	         //   Toast.makeText(test.this, "Authentication Success", Toast.LENGTH_LONG).show();
		    	        }
		    	    } catch (IllegalStateException e) {
		    	        e.printStackTrace();
		    	    } catch (IOException e) {
		    	        e.printStackTrace();
		    	    }
		    	} else {
		    	    Log.d(TAG, "Login failure");
		    	}
		       
		        return null;
		}
		protected void onPostExecute(Void Result){
			progressDialog .dismiss();

			/* progressDialog = ProgressDialog.show(test.this,
		             "", "Done...", true);*/
		}
		}

		/**
		* 認証できているかどうか
		* 
		* @return
		*/
		public static boolean getAutheticateState() {
		return sAuthenticate;
		}

		/**
		* 取得したトークンを返す
		* 
		* @return
		*/
		public static String getToken() {
		return sToken;
		}

		public static final String ANDROID = "android";
		public static final String APP_ENGINE = "ah";
		public static final String CALENDAR = "cl";
		public static final String MAIL = "mail";
		public static final String TALK = "talk";
		public static final String YOUTUBE = "youtube";
		public static final String FUSION_TABLES = "fusiontables";
		}
