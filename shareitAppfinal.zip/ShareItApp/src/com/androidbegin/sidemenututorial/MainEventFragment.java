package com.androidbegin.sidemenututorial;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.AsyncTask.Status;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import com.actionbarsherlock.app.SherlockFragment;


import com.parse.FindCallback;
import com.parse.GetDataCallback;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseObject;
import com.parse.ParseQuery;

public class MainEventFragment extends SherlockFragment {
	
	ListView listview;
	
	ProgressDialog mProgressDialog;
	ListViewAdapter adapter; 
	private List<WorldPopulation> WorldPopulationlist = null;
//	final EditText edit_text   = (EditText)findViewById(R.id.editText1);
	EditText editsearch; 
	WorldPopulation map;  
	byte[] byteArray;
	 String message;
	 private boolean isCancle = false;
	 View rootView ;
	 RemoteDataTask task;
	  View header ;
		  
	  static int default_value_city = 0;
	
		String city="������";
		AlertDialog d;
		Button btnCity;
		 List<ParseObject> 	ob;
		 ParseQuery<ParseObject> query ;
		 ImageButton btnRefersh ;
			private boolean flag = true;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		 rootView = inflater.inflate(R.layout.listview_main, container, false);
		return rootView;
	}

    public void onStart() {
        super.onStart();
        
        if(haveNetworkConnection()){
        if (!isCancle){
       task= new RemoteDataTask();
       task.execute();
        }
	/*	mProgressDialog = new ProgressDialog(getActivity());
		// Set progressdialog title
		mProgressDialog.setTitle("Parse.com Custom ListView Tutorial");
		// Set progressdialog message
		mProgressDialog.setMessage("Loading...");
		mProgressDialog.setIndeterminate(false);
		// Show progressdialog
		mProgressDialog.show();   
		 isCancle =false;
		

		WorldPopulationlist = new ArrayList<WorldPopulation>();
		try { 
			// Locate the class table named "City_of_event" in Parse.com
			ParseQuery<ParseObject> query = new ParseQuery<ParseObject>(
					"Events");  
			
		//	ParseFile fileObject = (ParseFile) object.get("Event_image");
			// Locate the column named "Event_namenum" in Parse.com and order list
			// by ascending
			//query.orderByAscending("Event_namenum");
			//edit_text.getText().toString()
			 
		
		   query.whereEqualTo("City_of_event","������"); 
		  
		   List<ParseObject> 	ob = query.find();
			 if (!isCancle){
			for (ParseObject City_of_event : ob) {
				
				 map = new WorldPopulation();
				map.setEvent_name((String) City_of_event.get("Event_name"));
				map.setCity_of_event((String) City_of_event.get("City_of_event"));
				map.setKind_of_Event((String) City_of_event.get("Kind_of_Event"));
				map.setOrganization((String) City_of_event.get("Organization"));
				map.setLocation((String) City_of_event.get("Location"));
				map.setTarget_Group((String) City_of_event.get("Target_Group"));
				map.setDescription((String) City_of_event.get("Description"));
				map.setId((String) City_of_event.getObjectId());
				 WorldPopulationlist.add(map);
				 if (!isCancle){
					listview = (ListView) rootView.findViewById(R.id.listview);
					// Pass the results into ListViewAdapter.java
					adapter = new ListViewAdapter( getActivity(),
							WorldPopulationlist);  
					// Binds the Adapter to the ListView
					listview.setAdapter(adapter);
				 }
					mProgressDialog.dismiss(); 
			//	map.setDate((String) City_of_event.get("Date"));
			// 
			 
			
				
				
				//  code image download
				
				/* query.findInBackground(new FindCallback<ParseObject>() {
					 public void done(List<ParseObject> objects, ParseException e) {
						 if (e == null&& objects != null && objects.size() > 0) {
						    for (final ParseObject parseObject : objects) {
						        ParseFile imageFile = (ParseFile) parseObject.get("Event_image");

										
									// images
									imageFile.getDataInBackground(new GetDataCallback() {
										@Override

										public void done(byte[] data, ParseException e) {
										 if ( data != null && data.length > 0) {
											Log.d("test", "We've got data in data.");
												// Decode the Byte[] into Bitmap
									Bitmap bmp = BitmapFactory.decodeByteArray(data, 0,data.length);
											
						
											ByteArrayOutputStream stream = new ByteArrayOutputStream();
										bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
											 byteArray = stream.toByteArray();
										 message = new String(byteArray);
											 Log.d("test",byteArray.toString());
											 
											 map.setImgByte((byte []) byteArray);
												
											 WorldPopulationlist.add(map);
											 if (!isCancle){
												listview = (ListView) rootView.findViewById(R.id.listview);
												// Pass the results into ListViewAdapter.java
												adapter = new ListViewAdapter( getActivity(),
														WorldPopulationlist);  
												// Binds the Adapter to the ListView
												listview.setAdapter(adapter);
											 }
												mProgressDialog.dismiss(); 
								



										} else {
													Log.d("test","There was a problem downloading the data.");
												}
									
						     //end done2
						
						             }

									
										});
										
						        	//end for
										}
						 
											
						         }else { Log.d("test","There was a problem downloading the data.");}
											
								
										}
						        	 });
						        	 
			*/
						// end  image code
	
		/*	} }else { query.cancel();}
		} catch (ParseException e) { 
			Log.e("Error", e.getMessage());
			e.printStackTrace();
		}*/
   	 header = getActivity().getLayoutInflater().inflate(R.layout.mainheadlis, null);
     btnCity = (Button)  header.findViewById(R.id.buttonCity);	
     btnRefersh = (ImageButton)  header.findViewById(R.id.imageButton1);
     btnCity.setText( city );
     listview = (ListView) getActivity().findViewById(R.id.listview);
	 listview .addHeaderView(header);
     btnCity.setOnClickListener(new View.OnClickListener() {

	        @Override
	        public void onClick(View v)
	        {
	            //c.show();
	            final String str[] = v.getResources().getStringArray(R.array.citylist);
	                AlertDialog.Builder builder =
	                  new AlertDialog.Builder(getActivity()).setSingleChoiceItems(
	                    str, default_value_city,new  DialogInterface.OnClickListener() {

	                    @Override
	                    public void onClick(DialogInterface dialog, int position)
	                    {
	                   
	                        default_value_city = position;
	                        btnCity.setText(str[position]);
	                        city=str[position];
	                        if (!isCancle){
	                            task= new RemoteDataTask();
	                            task.execute();
	                             }
	                        if(d.isShowing())
	                            d.dismiss();
	                    }
	                }).setTitle(getString(R.string.select_city));
	                d = builder.create();
	                d.show();
	            }
	        });
     
     
     
     
     btnRefersh.setOnClickListener(new View.OnClickListener() {

	        @Override
	        public void onClick(View v)
	        {
	            if (!isCancle){
                    task= new RemoteDataTask();
                    task.execute();
                     }
	        }
	           
	        });
        }else {showNoConnectionDialog(getActivity());}
		
	}
       // new RemoteDataTask().execute();
	public void onPause() {
	    super.onPause();
	    if(task != null && task.getStatus() == Status.RUNNING)
	        task.cancel(true);
	    
	     isCancle =true;
	  //   isCancle =true;
	}
	
/*	@Override
	public void onStop() {
	   super.onStop();

	    query.cancel();
	     isCancle =true;
	   
	}*/
	
    public void onResume() {
        super.onResume();
 
    }
   
    
    private class RemoteDataTask extends AsyncTask<Void, Void, Void> {
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			// Create a progressdialog
			mProgressDialog = new ProgressDialog(getActivity());
			// Set progressdialog title
			
			// Set progressdialog message
			mProgressDialog.setMessage("��� ���� ������� ���� �������� ...");
			mProgressDialog.setIndeterminate(false);
			// Show progressdialog
			mProgressDialog.show();     
			WorldPopulationlist = new ArrayList<WorldPopulation>();
		} 
		
	
			
		@Override
		protected Void doInBackground(Void... params) {
			// Create the array
	
		/*	WorldPopulationlist = new ArrayList<WorldPopulation>();
			try {
				// Locate the class table named "City_of_event" in Parse.com
				ParseQuery<ParseObject> query = new ParseQuery<ParseObject>(
						"Events");  
				
			//	ParseFile fileObject = (ParseFile) object.get("Event_image");
				// Locate the column named "Event_namenum" in Parse.com and order list
				// by ascending
				//query.orderByAscending("Event_namenum");
				//edit_text.getText().toString()
				
			   query.whereEqualTo("City_of_event","�������"); 
			   List<ParseObject> ob = query.find();
				for (ParseObject City_of_event : ob) {
					WorldPopulation map = new WorldPopulation();
					map.setEvent_name((String) City_of_event.get("Event_name"));
					map.setCity_of_event((String) City_of_event.get("City_of_event"));
					map.setKind_of_Event((String) City_of_event.get("Kind_of_Event"));
					map.setOrganization((String) City_of_event.get("Organization"));
					map.setLocation((String) City_of_event.get("Location"));
					map.setTarget_Group((String) City_of_event.get("Target_Group"));
					map.setDescription((String) City_of_event.get("Description"));
				//	map.setDate((String) City_of_event.get("Date"));
				//
				
				
					WorldPopulationlist.add(map);
					
					// 
			 /*query.findInBackground(new FindCallback<ParseObject>() {
				 public void done(List<ParseObject> objects, ParseException e) {
					 if (e == null&& objects != null && objects.size() > 0) {
					    for (final ParseObject parseObject : objects) {
					        ParseFile imageFile = (ParseFile) parseObject.get("Event_image");
					        		
							ProgressDialog dlgProgress;
							dlgProgress.setMessage("���� ����� ������"); 
									
								// images
								imageFile.getDataInBackground( new GetCallback<ParseObject>() {

									public void done(byte[] data, ParseException e) {
									 if ( data != null && data.length > 0) {
										Log.d("test", "We've got data in data.");
											// Decode the Byte[] into Bitmap
										Bitmap bmp = BitmapFactory.decodeByteArray(data, 0,data.length);
					
										// Get the ImageView from main.xml
										ImageView image = (ImageView) findViewById(R.id.image);

										// Set the Bitmap into the ImageView
										image.setImageBitmap(bmp);

										Dialog progressDialog;
										// Close progress dialog
										progressDialog.dismiss();

									} else {
												Log.d("test","There was a problem downloading the data.");
											}
								
					     //end done2
					
					             }

								@Override
								public void done(ParseObject object,ParseException e) {
						
											// TODO Auto-generated method stub
											
										} 
									});
									
					        	//end for
									}
										
					         }else { Log.d("test","There was a problem downloading the data.");}
										
							
									}
					        	 });*/
					     
					// end  image code
	/*		}
		} catch (ParseException e) { 
				Log.e("Error", e.getMessage());
				e.printStackTrace();
			}*/
			
			
			try { 
				// Locate the class table named "City_of_event" in Parse.com
			 query = new ParseQuery<ParseObject>(
						"Events");  
				
			//	ParseFile fileObject = (ParseFile) object.get("Event_image");
				// Locate the column named "Event_namenum" in Parse.com and order list
				// by ascending
				//query.orderByAscending("Event_namenum");
				//edit_text.getText().toString()
				 
			
			   query.whereEqualTo("City_of_event",city); 
			   query.orderByDescending("Date");
			  	ob = query.find();
				 if (!isCancle){
				for (ParseObject City_of_event : ob) {
					
					 map = new WorldPopulation();
					map.setEvent_name((String) City_of_event.get("Event_name"));
					map.setCity_of_event((String) City_of_event.get("City_of_event"));
					map.setKind_of_Event((String) City_of_event.get("Kind_of_Event"));
					map.setOrganization((String) City_of_event.get("Organization"));
					map.setLocation((String) City_of_event.get("Location"));
					map.setTarget_Group((String) City_of_event.get("Target_Group"));
					map.setDescription((String) City_of_event.get("Description"));
					map.setId((String) City_of_event.getObjectId());
					 map.setDate((Date)City_of_event.get("Date"));
					 WorldPopulationlist.add(map);
				/*	 if (!isCancle){
						listview = (ListView) rootView.findViewById(R.id.listview);
						// Pass the results into ListViewAdapter.java
						adapter = new ListViewAdapter( getActivity(),
								WorldPopulationlist);  
						// Binds the Adapter to the ListView
						listview.setAdapter(adapter);
					 }
						mProgressDialog.dismiss(); 
				//	map.setDate((String) City_of_event.get("Date"));
				// 
				 
				
					
					
					//  code image download
					
					/* query.findInBackground(new FindCallback<ParseObject>() {
						 public void done(List<ParseObject> objects, ParseException e) {
							 if (e == null&& objects != null && objects.size() > 0) {
							    for (final ParseObject parseObject : objects) {
							        ParseFile imageFile = (ParseFile) parseObject.get("Event_image");

											
										// images
										imageFile.getDataInBackground(new GetDataCallback() {
											@Override

											public void done(byte[] data, ParseException e) {
											 if ( data != null && data.length > 0) {
												Log.d("test", "We've got data in data.");
													// Decode the Byte[] into Bitmap
										Bitmap bmp = BitmapFactory.decodeByteArray(data, 0,data.length);
												
							
												ByteArrayOutputStream stream = new ByteArrayOutputStream();
											bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
												 byteArray = stream.toByteArray();
											 message = new String(byteArray);
												 Log.d("test",byteArray.toString());
												 
												 map.setImgByte((byte []) byteArray);
													
												 WorldPopulationlist.add(map);
												 if (!isCancle){
													listview = (ListView) rootView.findViewById(R.id.listview);
													// Pass the results into ListViewAdapter.java
													adapter = new ListViewAdapter( getActivity(),
															WorldPopulationlist);  
													// Binds the Adapter to the ListView
													listview.setAdapter(adapter);
												 }
													mProgressDialog.dismiss(); 
									



											} else {
														Log.d("test","There was a problem downloading the data.");
													}
										
							     //end done2
							
							             }

										
											});
											
							        	//end for
											}
							 
												
							         }else { Log.d("test","There was a problem downloading the data.");}
												
									
											}
							        	 });
							        	 
				*/
							// end  image code
		
				} }else { query.cancel();}
			} catch (ParseException e) { 
				Log.e("Error", e.getMessage());
				e.printStackTrace();
			}
	
			
			
			
			return null;
			
			
			
		
		 
		}
		
			
		@Override
		protected void onPostExecute(Void result) {
			// Locate the listview in listview_main.xml
	
			
			
			// Pass the results into ListViewAdapter.java
			adapter = new ListViewAdapter(getActivity(),
					WorldPopulationlist);  
			if(adapter.getCount() == 0 ){	new AlertDialog.Builder( getActivity())
			  .setTitle("������ ������ �� ������")
			    .setMessage("����� ������ ������ �� ������")
			    .setPositiveButton("�����", new DialogInterface.OnClickListener() {
			        public void onClick(DialogInterface dialog, int which) { 
			            // continue with delete
			        }
			     })
			  
			     .show(); }
			// Binds the Adapter to the ListView
			listview.setAdapter(adapter);
			// Close the progressdialog
			mProgressDialog.dismiss(); 
		
		
		//**************
		/*	editsearch = (EditText) findViewById(R.id.editText1);    
			 // Capture Text in EditText    
			editsearch.getText().toString();
			 editsearch.addTextChangedListener(new TextWatcher() {   
				 @Override               
				 public void afterTextChanged(Editable arg0) {            
					 // TODO Auto-generated method stub                  
					 String text = editsearch.getText().toString()         
							 .toLowerCase(Locale.getDefault());          
					 adapter.filter(text);                 }            
				 @Override               
				 public void beforeTextChanged(CharSequence arg0, int arg1,int arg2, int arg3) {  
					 // TODO Auto-generated method stub           
					 }             
				 @Override            
				 public void onTextChanged(CharSequence arg0, int arg1,int arg2, int arg3) { 
					 // TODO Auto-generated method stub              
					 }       
					 }); */
					 
			 }
		 }
    
    
    
    // ----------------- Check Network Connection ---------------------		


    private boolean haveNetworkConnection() {
        boolean haveConnectedWifi = false;
        boolean haveConnectedMobile = false;

        ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo[] netInfo = cm.getAllNetworkInfo();
        for (NetworkInfo ni : netInfo) {
            if (ni.getTypeName().equalsIgnoreCase("WIFI"))
                if (ni.isConnected())
                    haveConnectedWifi = true;
            if (ni.getTypeName().equalsIgnoreCase("MOBILE"))
                if (ni.isConnected())
                    haveConnectedMobile = true;
        }
        return haveConnectedWifi || haveConnectedMobile;
    }


      // ----------------- Show Setting Dialog ---------------------	

    public static void showNoConnectionDialog(Context ctx1) 
    {
        final Context ctx = ctx1;
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
        builder.setCancelable(true);
        builder.setMessage("������ ����� �������� ");
        builder.setTitle("������ ����� �������� ");
        builder.setPositiveButton("������ ", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) 
            {
                ctx.startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
            }
        });

        builder.setNegativeButton("����� ", new DialogInterface.OnClickListener() 
        {
            public void onClick(DialogInterface dialog, int which) 
            {
                return;
            }
        });

        builder.setOnCancelListener(new DialogInterface.OnCancelListener() 
        {
            public void onCancel(DialogInterface dialog) {
                return;
            }
        });

        builder.show();
    }
    
}

