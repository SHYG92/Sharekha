package com.androidbegin.sidemenututorial;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.actionbarsherlock.app.SherlockFragment;
import com.androidbegin.sidemenututorial.Fragment1.SelectDateFragment;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseObject;
import com.parse.ParseRelation;
import com.parse.ParseUser;
import com.parse.SaveCallback;

@SuppressLint("ValidFragment")
public class AddEventFragment extends SherlockFragment {
	
EditText mEdit;
Calendar calendar;
Date CDate;
int RESULT_LOAD_IMAGE=1;
public  Bitmap bitmap;
public byte[] image;
boolean Ename =false ;
boolean Ecity =false ;
boolean Etargt =false ;
boolean Etype =false ;
boolean Edate =false ;
boolean Eloction =false ;
boolean Eimage =false ;
String pictureName;
static int default_value_city = 0;
static int default_value_type = 0;
static int default_value_tGroup = 0;
String city="";
String type="";
String tGroup="";
AlertDialog d;
AlertDialog d2;
View rootView ;
public View onCreateView(LayoutInflater inflater, ViewGroup container,
		Bundle savedInstanceState) {
	 rootView = inflater.inflate(R.layout.addevent, container, false);
	return rootView;
}

public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

}
   @Override
    public void onStart() {
        super.onStart();
    Button  rtn = (Button)getActivity().findViewById(R.id.button1);
    Button  rtnImage = (Button)getActivity().findViewById(R.id.button3);
    ImageButton rtnDate =(ImageButton)getActivity().findViewById(R.id.button2);
    final EditText edit_text_name   = (EditText)getActivity().findViewById(R.id.editText1);
    final EditText edit_text_Date   = (EditText)getActivity().findViewById(R.id.editText2);
    final EditText edit_text_loction   = (EditText)getActivity().findViewById(R.id.editText3);
    final EditText edit_text_org   = (EditText)getActivity().findViewById(R.id.editText4);
    final EditText  edit_text_descripe   = (EditText)getActivity().findViewById(R.id.editText5);
    final TextView EnameText =(TextView)getActivity().findViewById(R.id.textView1);
    final TextView SpTextCity =(TextView)getActivity().findViewById(R.id.textView2);
    final TextView SpTextType =(TextView)getActivity().findViewById(R.id.textView3);
    final TextView SpTextTargt =(TextView)getActivity().findViewById(R.id.textView4);
    final TextView DateText =(TextView)getActivity().findViewById(R.id.textView5);
    final TextView LoctionText =(TextView)getActivity().findViewById(R.id.textView6);
    final TextView ImgeText =(TextView)getActivity().findViewById(R.id.textView7);
    
    final TextView PlzText =(TextView)getActivity().findViewById(R.id.textView9);
    final TextView QText =(TextView)getActivity().findViewById(R.id.textView8);
    
    final Button btnCity = (Button) getActivity().findViewById(R.id.button4);
    final Button btnType = (Button) getActivity().findViewById(R.id.button5);
    final Button btnGrpup = (Button) getActivity().findViewById(R.id.button6);
    final ParseUser currentUser = ParseUser.getCurrentUser();
 
    rtn .setOnClickListener(
              new View.OnClickListener()
              {
                  public void onClick(View view)
                  {
     
            		  // ----------------- Check Network Connection ---------------------	
                	  
                	  if(haveNetworkConnection()){
                		
          				if (currentUser != null) {
                	  // ----------------- Form Validation   ---------------------
                	  if( edit_text_name.getText().toString().length() == 0 || edit_text_name.getText().toString().trim().equals("")  ){
                		  EnameText.setError( "! ��� �������� �����" );
                		  Ename=false ;
                	  }
                	  else if( edit_text_name.getText().toString().length() != 0 || ! (edit_text_name.getText().toString().trim().equals(""))  ){
                		  EnameText.setError( null );
                		  Ename=true ; 
                	  }
                	   if (  city.equals("")  ){
                		  SpTextCity.setError( "! ������� ������ " );
                		  Ecity =false ;} 
                	  else if (  ! (city.equals("") )  ){
                		  SpTextCity.setError( null );
                		  Ecity =true;}
                	  
                	  if (   tGroup.equals("") ){
                		  SpTextTargt.setError( "! ������� ������ " );
                		  Etargt =false ;}
                	  else if ( ! (tGroup.equals(""))  ){
                		  SpTextTargt.setError( null );
                		  Etargt =true ;}
                	  
                	   if ( type.equals("")  ){
                		  SpTextType.setError( "! ������� ������ " );
                		  Etype =false ;}
                	  else if (  ! (type.equals(""))  ){
                		  SpTextType.setError( null );
                		  Etype =true ;}
                	   
	                   if(  edit_text_Date .getText().toString().length() == 0 ||  edit_text_Date.getText().toString().trim().equals("")  ){
	                	   DateText.setError( "! ��� �������� �����" );
	                	   Edate =false ;}
	                   else if(  edit_text_Date .getText().toString().length() != 0 || ! ( edit_text_Date.getText().toString().trim().equals(""))  ){
	                	   DateText.setError( null );       
	                	   Edate =true ;}
	                	  
	                	if(edit_text_loction.getText().toString().length() == 0 || edit_text_loction.getText().toString().trim().equals("")  ){
	                		LoctionText.setError( "! ��� �������� �����" );
	                	
	                		Eloction =false ;}
	                	 else if( edit_text_loction.getText().toString().length() != 0 || ! (edit_text_loction.getText().toString().trim().equals(""))){
	                		 LoctionText.setError( null );
	                		
	                		 Eloction =true ;}
                	  
                	   if ( image == null ){
                		   ImgeText.setError( "! ���� �������� �����" );
                		   Eimage =false ;}
                	   else  if ( image != null  ){
                		   ImgeText.setError( null );
                		   Eimage =true ;}
                	 
                	   
                	   
                	   if (!(Ename || Ecity || Etargt || Etype  || Edate || Eloction || Eimage)){
                		   QText.setError( "! ��� �������� �����" );
	                	   PlzText.setText("������ ������ , ���� �������  ");
                	   }
                	   
                	   
                		  // ----------------- Add to Parse.com ---------------------
                	 if (Ename && Ecity && Etargt && Etype  && Edate && Eloction && Eimage){
                		 
                		  QText .setError( null );
                		  PlzText.setText(null); 
                		  final ParseObject  myEvent = new ParseObject("Events");
	                	  
	                	  ParseFile file = new ParseFile(pictureName +".png", image);
                	  
                      // Upload the image into Parse Cloud
                     //  file.saveInBackground();
                       
                       file.saveInBackground(new SaveCallback() {
                 		  
                 		  

              	         public void done(ParseException e) {
              	                 if (e == null) {
              	                	 ParseUser user = ParseUser.getCurrentUser();
              	                	 // user_events
             	             /*   	 ParseRelation<ParseObject> relation = user.getRelation("user_events");
             	                      relation.add(myEvent);
             	                	 user.saveInBackground();*/
              	                	 

              	                 } else {
              	                	 Toast.makeText(getActivity(), "notYet", 0).show();
              	                	
              	                 }
              	               }

						
              	             });
                       Log.v("DateCon", image.toString()); 
                	 
                      myEvent .put("Event_name", edit_text_name.getText().toString().trim());
                     myEvent .put("Target_Group", tGroup); 
                    myEvent .put("Kind_of_Event", type);  
                	  myEvent .put("City_of_event", city); 
                	  myEvent .put("Organization", edit_text_org.getText().toString().trim()); 
                      myEvent .put("Location", edit_text_loction .getText().toString().trim()); 
                      myEvent .put("Description", edit_text_descripe.getText().toString().trim()); 
                      myEvent .put("Date", CDate );
                      myEvent .put("Event_image", file);
                      
                    
       
                      // Show a simple toast message
                   //   Toast.makeText(getActivity(), "Image Uploaded",
                   //           Toast.LENGTH_SHORT).show();
                     
                      final ProgressDialog dialog = new ProgressDialog(getActivity());
                      
                      // make the progress bar cancelable
                      dialog.setCancelable(false);
                       
                      // set a message text
                      dialog.setMessage("���� �������� ��� ���� ������� ...");
                       
                      // show it
                      dialog.show();
                	  myEvent.saveInBackground(new SaveCallback() {
                		  
                		  

                	         public void done(ParseException e) {
                	                 if (e == null) {
                	                	 ParseUser user = ParseUser.getCurrentUser();
                	                	 // user_events
               	               	 ParseRelation<ParseObject> relation = user.getRelation("user_events");
               	                      relation.add(myEvent);
               	                	 user.saveInBackground();
                	                
                	                	 Log.v("Done", "Done"); 
                	                	 dialog.dismiss();
                	       			 // getFragmentManager().beginTransaction().replace(R.id.content_frame,  new MainEventFragment()).commit();
                	       		//	MainActivity.currnetItem = 1;
                	       		//	MainActivity.flagMain=true;
                	                	 
                	                     MainActivity feeds = (MainActivity) getActivity();
               			              feeds.startFrag();  
                	       	
                	                 } else {
                	              
                	                	 Log.v("notYet", "notYet"); 
                	                	 Log.v("Error ",  e.getMessage());
                	                	 Toast.makeText(getActivity(), e.getMessage() , 0).show();
                	                	 dialog.dismiss();
                	                 }
                	               }

						
                	             });
                	  
                	 
               
             } 
          				} else {
      					  // show the signup or login screen
        					new AlertDialog.Builder( getActivity())
        					  .setTitle("����� ������")
        				    .setMessage("�� ������ ������ ������ �� ����� ������")
        				    .setPositiveButton("�����", new DialogInterface.OnClickListener() {
        				        public void onClick(DialogInterface dialog, int which) { 
        				            // continue with delete
        				        }
        				     })
        				  
        				     .show();
          				}
                	 } else {showNoConnectionDialog(getActivity());}
                  }
        });
    
	  // ----------------- Open Gallery  ---------------------	        
    rtnImage.setOnClickListener(
              new View.OnClickListener()
              {
                  public void onClick(View view)
                  {
                	     Intent i = new Intent(
                	                Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                	                startActivityForResult(i, RESULT_LOAD_IMAGE);
                  }
        });
    
    // ----------------- City  ---------------------	
    
    
   
    btnCity .setOnClickListener(new View.OnClickListener() {

    @Override
    public void onClick(View v)
    {
        //c.show();
        final String str[] = v.getResources().getStringArray(R.array.citylist);
            AlertDialog.Builder builder =
              new AlertDialog.Builder(getActivity()).setSingleChoiceItems(
                str, default_value_city,new  DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int position)
                {
                 
                    default_value_city = position;
                    btnCity.setText(str[position]);
                    city=str[position];
                    if(d.isShowing())
                        d.dismiss();
                }
            }).setTitle(getString(R.string.select_city));
            d = builder.create();
            d.show();
        }
    });
    
    // ----------------- Type ---------------------	
    
  
    btnType.setOnClickListener(new View.OnClickListener() {

    @Override
    public void onClick(View v)
    {
        //c.show();
        final String str[] = v.getResources().getStringArray(R.array.typelist);
            AlertDialog.Builder builder =
              new AlertDialog.Builder(getActivity()).setSingleChoiceItems(
                str, default_value_type,new  DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int position)
                {
               
                    default_value_type = position;
                    btnType.setText(str[position]);
                    type=str[position];
                    if(d.isShowing())
                        d.dismiss();
                }
            }).setTitle(getString(R.string.select_type));
            d = builder.create();
            d.show();
        }
    });
    

    // ----------------- Target Group ---------------------	
      
    btnGrpup.setOnClickListener(new View.OnClickListener() {

    @Override
    public void onClick(View v)
    {
        //c.show();
        final String str[] = v.getResources().getStringArray(R.array.targtlist);
            AlertDialog.Builder builder =
              new AlertDialog.Builder(getActivity()).setSingleChoiceItems(
                str, default_value_tGroup,new  DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int position)
                {
           
                    default_value_tGroup = position;
                    btnGrpup.setText(str[position]);
                    tGroup=str[position];
                    if(d.isShowing())
                        d.dismiss();
                }
            }).setTitle(getString(R.string.select_targt));
            d = builder.create();
            d.show();
        }
    });
    

    
    
    
    rtnDate.setOnClickListener(new OnClickListener() {
    	 

		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			selectDate(rootView);

		}

	});
	}  
        




// ----------------- Select Date  ---------------------
public void selectDate(View view) {

    DialogFragment newFragment = new SelectDateFragment();
    newFragment.show(getFragmentManager().beginTransaction(), "DatePicker");
}

// -----------------Populate  Date ---------------------
public void populateSetDate(int year, int month, int day) {
	mEdit = (EditText) getActivity().findViewById(R.id.editText2);
	mEdit.setText(month+"/"+day+"/"+year);
	String date =Integer.toString(year)+"-"+ Integer.toString( month) +"-"+ Integer.toString(day);
    CDate = convertDate(date);
    Log.v("Date", date); 

	
	
}


// ----------------- Convert Date    ---------------------
  public Date convertDate (String date){
	  
	  final String DEvent="yyyy-MM-dd";
	  SimpleDateFormat dateFormat = new SimpleDateFormat(DEvent);
	    Date convertedDate = new Date();
	    try {
			convertedDate = dateFormat.parse(date);
			 Log.v("DateCon", convertedDate.toString()); 
			
		} catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return convertedDate;
  }
  
  
  
  // ----------------- Upload Image from gallery   ---------------------
  public void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);
        
 if (requestCode == RESULT_LOAD_IMAGE && resultCode == getActivity().RESULT_OK && null != data) {
             Uri selectedImage = data.getData();
             String[] filePathColumn = { MediaStore.Images.Media.DATA };
             
             Cursor cursor = getActivity().getContentResolver().query(selectedImage,
                     filePathColumn, null, null, null);
             cursor.moveToFirst();
     
             int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
             String picturePath = cursor.getString(columnIndex);
             cursor.close();
             Log.v("DateCon", picturePath); 
             pictureName = selectedImage.getLastPathSegment().toString();
             
             
             // String picturePath contains the path of selected Image
            
             // Show the Selected Image on ImageView
             ImageView imageView = (ImageView) getActivity().findViewById(R.id.imageView1);
             
              bitmap = BitmapFactory.decodeFile(picturePath);
              Bitmap bmp2 = scaleDownBitmap(bitmap, 450, getActivity());
              imageView.setImageBitmap(bmp2);
                // Convert it to byte
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                // Compress image to lower quality scale 1 - 100
                bmp2.compress(Bitmap.CompressFormat.PNG, 100, stream);
                image = stream.toByteArray();
                Log.v("DateCon", image.toString()); 
           
       }  // if Loop
   
    }    
  
  
  
	public static Bitmap scaleDownBitmap(Bitmap photo, int newHeight, Context context) {

		final float densityMultiplier = context.getResources().getDisplayMetrics().density;        

		int h= (int) (newHeight*densityMultiplier);
		int w= (int) (h * photo.getWidth()/((double) photo.getHeight()));

		photo=Bitmap.createScaledBitmap(photo, w, h, true);

		return photo;
		}
  
  // ----------------- Date Picker Dialog ---------------------


public  class SelectDateFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		calendar = Calendar.getInstance();


		int yy = calendar.get(Calendar.YEAR);
		int mm = calendar.get(Calendar.MONTH);
		int dd = calendar.get(Calendar.DAY_OF_MONTH);
	
    
		return new DatePickerDialog(getActivity(), this, yy, mm, dd);
	}
	
	@Override
	public void onDateSet(DatePicker view, int yy, int mm, int dd) {
		populateSetDate(yy, mm+1, dd);
	}

}

  // ----------------- Check Network Connection ---------------------		


private boolean haveNetworkConnection() {
    boolean haveConnectedWifi = false;
    boolean haveConnectedMobile = false;

    ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
    NetworkInfo[] netInfo = cm.getAllNetworkInfo();
    for (NetworkInfo ni : netInfo) {
        if (ni.getTypeName().equalsIgnoreCase("WIFI"))
            if (ni.isConnected())
                haveConnectedWifi = true;
        if (ni.getTypeName().equalsIgnoreCase("MOBILE"))
            if (ni.isConnected())
                haveConnectedMobile = true;
    }
    return haveConnectedWifi || haveConnectedMobile;
}


  // ----------------- Show Setting Dialog ---------------------	

public static void showNoConnectionDialog(Context ctx1) 
{
    final Context ctx = ctx1;
    AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
    builder.setCancelable(true);
    builder.setMessage("������ ����� �������� ");
    builder.setTitle("������ ����� �������� ");
    builder.setPositiveButton("������ ", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int which) 
        {
            ctx.startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
        }
    });

    builder.setNegativeButton("����� ", new DialogInterface.OnClickListener() 
    {
        public void onClick(DialogInterface dialog, int which) 
        {
            return;
        }
    });

    builder.setOnCancelListener(new DialogInterface.OnCancelListener() 
    {
        public void onCancel(DialogInterface dialog) {
            return;
        }
    });

    builder.show();
}

 @Override
	public void onResume() {
			super.onResume();
			getActivity().invalidateOptionsMenu();
			 
			//getFragmentManager().popBackStack();
		}



}
