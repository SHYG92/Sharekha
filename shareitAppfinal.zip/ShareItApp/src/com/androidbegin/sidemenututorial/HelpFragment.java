package com.androidbegin.sidemenututorial;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.actionbarsherlock.app.SherlockFragment;

public class HelpFragment extends SherlockFragment {
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.help, container, false);
		return rootView;
	}
	
	 @Override
	    public void onStart() {
	        super.onStart();
	    
	 }

}


