/** Automatically generated file. DO NOT MODIFY */
package com.androidbegin.sidemenututorial;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}